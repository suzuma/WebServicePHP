<?php
/**
 * Created by PhpStorm.
 * User: SuZuMa
 * Date: 14/04/2017
 * Time: 13:37
 */

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    protected  $table='productos';

}