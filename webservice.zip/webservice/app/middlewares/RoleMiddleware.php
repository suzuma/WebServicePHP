<?php
namespace App\Middlewares;

class RoleMiddleware {
    public static function isAdmin() {

    }

    public static function isSeller() {

    }

    public static function isAnalyst() {

    }
}